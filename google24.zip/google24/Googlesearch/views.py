from django.shortcuts import render


def Googlesearch(request):

    return render(request, 'Googlesearch/index.html')